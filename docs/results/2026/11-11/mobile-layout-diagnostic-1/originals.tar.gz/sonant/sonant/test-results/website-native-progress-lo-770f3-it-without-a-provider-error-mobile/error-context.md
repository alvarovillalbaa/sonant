# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: website.spec.ts >> native progress loop plays and navigation stops it without a provider error
- Location: tests/e2e/website.spec.ts:184:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to content" [ref=e3] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e4]:
    - generic [ref=e5]:
      - link "Sonant home" [ref=e6] [cursor=pointer]:
        - /url: "#/"
        - generic [ref=e8]: sonant.
      - generic [ref=e9]:
        - button "Sound on" [pressed] [ref=e10] [cursor=pointer]
        - button "Open menu" [ref=e16] [cursor=pointer]
  - main [ref=e18]:
    - generic [ref=e19]:
      - generic [ref=e20]:
        - generic [ref=e21]: THE LISTENING ROOM
        - heading "Know what played. Understand what didn’t." [level=1] [ref=e22]: Know what played.Understand what didn’t.
        - paragraph [ref=e23]: Live, local diagnostics from this website’s actual sound system. No account. No telemetry.
      - generic [ref=e24]:
        - article [ref=e25]:
          - generic [ref=e28]: Active voices
          - strong [ref=e29]: 0 / 4
        - article [ref=e30]:
          - generic [ref=e37]: Audio context
          - strong [ref=e38]: suspended
        - article [ref=e39]:
          - generic [ref=e44]: Accepted by provider
          - strong [ref=e45]:
            - text: "2"
            - generic [ref=e46]: / 2
        - article [ref=e47]:
          - generic [ref=e51]: Suppressed or blocked
          - strong [ref=e52]: "0"
      - generic [ref=e53]:
        - generic [ref=e54]:
          - generic [ref=e55]: TRY THE POLICY
          - generic [ref=e56]:
            - button "quiet" [ref=e57] [cursor=pointer]
            - button "balanced" [pressed] [ref=e58] [cursor=pointer]
            - button "expressive" [ref=e59] [cursor=pointer]
        - generic [ref=e60] [cursor=pointer]:
          - checkbox "Speech is active Suppress low-priority cues" [ref=e61]
          - generic [ref=e62]:
            - text: Speech is active
            - generic [ref=e63]: Suppress low-priority cues
        - button "Trigger a burst" [ref=e64] [cursor=pointer]
        - button "Try an error" [ref=e67] [cursor=pointer]
      - generic [ref=e70]:
        - generic [ref=e71]:
          - strong [ref=e74]: EVENT TRACE
          - generic [ref=e75]:
            - button "Export JSON" [ref=e76] [cursor=pointer]
            - button "Clear trace" [ref=e79] [cursor=pointer]
        - generic [ref=e83]:
          - textbox "Filter trace" [ref=e84]:
            - /placeholder: Filter by event, source, or reason…
          - combobox "Filter by decision" [ref=e85]:
            - option "All decisions" [selected]
            - option "Played"
            - option "Suppressed"
            - option "Blocked"
            - option "Error"
        - region "Event trace table" [ref=e86]:
          - table [ref=e87]:
            - rowgroup [ref=e88]:
              - row [ref=e89]:
                - columnheader "Time" [ref=e90]
                - columnheader "Semantic event" [ref=e91]
                - columnheader "Source / surface" [ref=e92]
                - columnheader "Decision" [ref=e93]
                - columnheader "Reason / lifecycle" [ref=e94]
                - columnheader "Replay" [ref=e95]
            - rowgroup [ref=e97]:
              - row [ref=e98]:
                - cell "12:01:55" [ref=e99]
                - cell [ref=e100]:
                  - code [ref=e101]: agent.thinking
                - cell "AgentExample examples" [ref=e102]:
                  - text: AgentExample
                  - generic [ref=e103]: examples
                - cell "played" [ref=e104]
                - cell "Ended" [ref=e105]
                - cell [ref=e106]:
                  - button "Replay agent.thinking" [ref=e107] [cursor=pointer]
              - row [ref=e110]:
                - cell "12:01:55" [ref=e111]
                - cell [ref=e112]:
                  - code [ref=e113]: action.select
                - cell "— global" [ref=e114]:
                  - text: —
                  - generic [ref=e115]: global
                - cell "played" [ref=e116]
                - cell "Ended" [ref=e117]
                - cell [ref=e118]:
                  - button "Replay action.select" [ref=e119] [cursor=pointer]
      - paragraph [ref=e122]: “Played” means the provider accepted a voice. It cannot prove your device was audible. Only event names, source labels, policy decisions, and preferences are kept in this bounded local trace.
  - contentinfo [ref=e123]:
    - link "Sonant home" [ref=e124] [cursor=pointer]:
      - /url: "#/"
      - generic [ref=e126]: sonant.
    - paragraph [ref=e127]: A little sound. A lot more feeling.
    - generic [ref=e128]:
      - generic [ref=e129]: Original sounds · MIT licensed
      - link "Source code" [ref=e130] [cursor=pointer]:
        - /url: https://github.com/alvarovillalbaa/sonant
      - link "Add with AI" [ref=e134] [cursor=pointer]:
        - /url: "#/docs/ai"
  - status [ref=e138]: "agent.thinking: played"
```

# Test source

```ts
  112 |       } finally {
  113 |         if (context) void context.close();
  114 |       }
  115 |     });
  116 |     console.log("Native Web Audio diagnostic:", JSON.stringify(probe));
  117 |     console.log(
  118 |       "Audio lifecycle:",
  119 |       await page.evaluate(() =>
  120 |         JSON.stringify(
  121 |           (window as unknown as { __sonantAudioDiagnostics: unknown[] }).__sonantAudioDiagnostics,
  122 |         ),
  123 |       ),
  124 |     );
  125 |     await page.goto("/#/devtools");
  126 |     console.log("Sonant diagnostic:", await page.locator(".devtools-metrics").innerText());
  127 |     throw error;
  128 |   }
  129 |   if (testInfo.project.name === "firefox")
  130 |     console.log(
  131 |       "Firefox audio lifecycle:",
  132 |       await page.evaluate(() =>
  133 |         JSON.stringify(
  134 |           (window as unknown as { __sonantAudioDiagnostics: unknown[] }).__sonantAudioDiagnostics,
  135 |         ),
  136 |       ),
  137 |     );
  138 |   await page.screenshot({ path: testInfo.outputPath("preview.png") });
  139 |   await page.getByRole("textbox", { name: "Search sounds" }).fill("does-not-exist");
  140 |   await expect(page.getByText("No sounds found.")).toBeVisible();
  141 |   await page.getByRole("button", { name: "Clear filters" }).click();
  142 |   await expect(page.getByRole("button", { name: "Preview Success", exact: true })).toBeVisible();
  143 |   await page.goto("/#/devtools");
  144 |   await expect(page.locator(".trace-panel")).toContainText("state.success");
  145 |   await expect(page.locator(".trace-panel")).toContainText("played");
  146 |   expect(errors).toEqual([]);
  147 | });
  148 | test("configurator produces exact CLI options and a downloadable source bundle", async ({
  149 |   page,
  150 | }) => {
  151 |   await page.goto("/#/create");
  152 |   await page.getByRole("button", { name: /WARM & UNHURRIED/ }).click();
  153 |   await page.getByRole("button", { name: /quiet.*Outcomes/ }).click();
  154 |   await expect(page.locator(".builder-summary .code-block")).toContainText(
  155 |     "--theme soft --profile quiet",
  156 |   );
  157 |   await page.getByLabel("async-action", { exact: false }).check();
  158 |   const downloaded = page.waitForEvent("download");
  159 |   await page.getByRole("button", { name: "Download source bundle" }).click();
  160 |   const download = await downloaded;
  161 |   expect(download.suggestedFilename()).toBe("sonant-kit.json");
  162 |   const stream = await download.createReadStream();
  163 |   let content = "";
  164 |   for await (const chunk of stream!) content += chunk;
  165 |   const data = JSON.parse(content);
  166 |   expect(data.files["components/sonant/async-action.tsx"]).toContain("operation.reject");
  167 |   expect(JSON.parse(data.files["sonant.config.json"]).theme).toBe("soft");
  168 | });
  169 | test("examples resolve and fail visibly, native dialog restores focus", async ({ page }) => {
  170 |   await page.goto("/#/examples");
  171 |   await page.getByRole("button", { name: "Save changes", exact: true }).click();
  172 |   await expect(page.getByText("Your changes have been saved.")).toBeVisible();
  173 |   await page.getByRole("button", { name: "Try failure" }).click();
  174 |   await expect(page.getByText("Could not save. Please try again.")).toBeVisible();
  175 |   const open = page.getByRole("button", { name: "Open a dialog" });
  176 |   await open.click();
  177 |   await expect(page.getByRole("dialog")).toBeVisible();
  178 |   await page.keyboard.press("Escape");
  179 |   await expect(page.getByRole("dialog")).not.toBeVisible();
  180 |   await expect(open).toBeFocused();
  181 |   await page.getByRole("button", { name: "Run workflow" }).click();
  182 |   await expect(page.getByText("Your summary is ready.")).toBeVisible();
  183 | });
  184 | test("native progress loop plays and navigation stops it without a provider error", async ({ page }, testInfo) => {
  185 |   const activate = async (control: ReturnType<typeof page.getByRole>) => {
  186 |     if (testInfo.project.name === "mobile") await control.tap();
  187 |     else await control.click();
  188 |   };
  189 |   await page.goto("/#/examples");
  190 |   await activate(page.getByRole("button", { name: "Sound off", exact: true }));
  191 |   await activate(page.getByRole("button", { name: "Run workflow", exact: true }));
  192 |   await expect(page.locator(".audio-announcement")).toHaveText("agent.thinking: played");
  193 |   const menu = page.getByRole("button", { name: "Open menu", exact: true });
  194 |   if (await menu.isVisible()) await activate(menu);
  195 |   await activate(page.locator("header nav").getByRole("link", { name: "Devtools", exact: true }));
  196 |   const row = page.locator("tbody tr").filter({ hasText: "agent.thinking" });
  197 |   await expect(row).toContainText("played");
  198 |   await expect(row).toContainText("Ended");
  199 |   await expect(row).not.toContainText("provider");
  200 |   await expect(page.locator(".devtools-metrics article").filter({ hasText: "Active voices" }).locator("strong")).toHaveText("0 / 4");
  201 |   console.log("Sonant navigation layout:", JSON.stringify(await page.evaluate(() => {
  202 |     const root = document.documentElement;
  203 |     return {
  204 |       innerWidth, scrollX, scrollY, clientWidth: root.clientWidth, scrollWidth: root.scrollWidth,
  205 |       visual: window.visualViewport && { width: visualViewport!.width, height: visualViewport!.height, scale: visualViewport!.scale, left: visualViewport!.offsetLeft, top: visualViewport!.offsetTop },
  206 |       nodes: Array.from(document.querySelectorAll("body *")).slice(0, 500).map(node => {
  207 |         const rect = node.getBoundingClientRect(), style = getComputedStyle(node);
  208 |         return { tag: node.tagName, id: node.id, className: node.getAttribute("class"), left: rect.left, right: rect.right, width: rect.width, cssWidth: style.width, minWidth: style.minWidth, maxWidth: style.maxWidth, display: style.display, position: style.position, overflowX: style.overflowX, parent: node.parentElement?.tagName + "." + node.parentElement?.className };
  209 |       }).filter(node => node.right > root.clientWidth + 1),
  210 |     };
  211 |   })));
> 212 |   await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth)).toBe(true);
      |                                                                                                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  213 |   await expect.poll(() => page.evaluate(() => window.visualViewport?.offsetTop ?? 0)).toBe(0);
  214 |   const [download] = await Promise.all([
  215 |     page.waitForEvent("download"),
  216 |     activate(page.getByRole("button", { name: "Export JSON", exact: true })),
  217 |   ]);
  218 |   expect(download.suggestedFilename()).toBe("sonant-trace.json");
  219 |   expect(await download.failure()).toBeNull();
  220 | });
  221 | test("mute persists, policy suppression is visible, and traces export", async ({ page }) => {
  222 |   await page.goto("/#/devtools");
  223 |   await page.getByRole("button", { name: "Sound off", exact: true }).click();
  224 |   await page.getByRole("button", { name: "Trigger a burst" }).click();
  225 |   await expect(page.locator("tbody")).toContainText("cooldown");
  226 |   await page.getByRole("button", { name: "Sound on", exact: true }).click();
  227 |   await page.reload();
  228 |   await expect(page.getByRole("button", { name: "Sound off", exact: true })).toBeVisible();
  229 |   await page.getByRole("button", { name: "Try an error" }).click();
  230 |   await expect(page.locator("tbody")).toContainText("muted");
  231 |   const downloaded = page.waitForEvent("download");
  232 |   await page.getByRole("button", { name: "Export JSON" }).click();
  233 |   expect((await downloaded).suggestedFilename()).toBe("sonant-trace.json");
  234 | });
  235 | for (const route of ["/", "/#/create", "/#/examples", "/#/devtools", "/#/docs"]) {
  236 |   test(`${route} has no serious accessibility violations or horizontal overflow`, async ({
  237 |     page,
  238 |   }) => {
  239 |     await page.goto(route);
  240 |     await expect(page.locator("main h1")).toBeVisible();
  241 |     const result = await new AxeBuilder({ page })
  242 |       .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
  243 |       .analyze();
  244 |     expect(
  245 |       result.violations
  246 |         .filter((v) => ["serious", "critical"].includes(v.impact ?? ""))
  247 |         .map((v) => ({
  248 |           rule: v.id,
  249 |           nodes: v.nodes.map((n) => ({ target: n.target, summary: n.failureSummary })),
  250 |         })),
  251 |       `${route} accessibility`,
  252 |     ).toEqual([]);
  253 |     expect(
  254 |       await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth),
  255 |       `${route} overflow`,
  256 |     ).toBe(true);
  257 |   });
  258 | }
  259 | 
```